package com.fpspvp.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.util.ArrayDeque;
import java.util.Deque;

public class HudOverlay {

    private final Deque<Long> clickTimes = new ArrayDeque<Long>();
    private boolean lastLeftDown = false;
    private long lastHitTime = 0L;

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        boolean leftDown = Mouse.isButtonDown(0);
        if (leftDown && !lastLeftDown) {
            clickTimes.addLast(System.currentTimeMillis());
        }
        lastLeftDown = leftDown;

        long now = System.currentTimeMillis();
        while (!clickTimes.isEmpty() && now - clickTimes.peekFirst() > 1000) {
            clickTimes.pollFirst();
        }
    }

    @SubscribeEvent
    public void onAttack(LivingAttackEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer != null && event.getSource() != null
                && event.getSource().getEntity() == mc.thePlayer) {
            lastHitTime = System.currentTimeMillis();
        }
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.gameSettings.showDebugInfo) return;

        ScaledResolution sr = new ScaledResolution(mc);
        FontRenderer fr = mc.fontRendererObj;
        int x = 5, y = 5;

        if (FpsPvpHud.config.showFps) {
            fr.drawStringWithShadow("FPS: " + Minecraft.getDebugFPS(), x, y, 0xFFFFFF);
            y += 10;
        }
        if (FpsPvpHud.config.showCps) {
            fr.drawStringWithShadow("CPS: " + clickTimes.size(), x, y, 0xFFFFFF);
            y += 10;
        }
        if (FpsPvpHud.config.showKeystrokes) {
            drawKeystrokes(mc, sr, fr);
        }
        if (FpsPvpHud.config.showHitColor) {
            drawHitFlash(sr);
        }
    }

    private void drawKeystrokes(Minecraft mc, ScaledResolution sr, FontRenderer fr) {
        int size = 20;
        int baseX = sr.getScaledWidth() - size * 3 - 10;
        int baseY = sr.getScaledHeight() - size * 2 - 10;

        drawKey(fr, mc.gameSettings.keyBindForward, baseX + size, baseY, size, "W");
        drawKey(fr, mc.gameSettings.keyBindLeft, baseX, baseY + size, size, "A");
        drawKey(fr, mc.gameSettings.keyBindBack, baseX + size, baseY + size, size, "S");
        drawKey(fr, mc.gameSettings.keyBindRight, baseX + size * 2, baseY + size, size, "D");
    }

    private void drawKey(FontRenderer fr, KeyBinding kb, int x, int y, int size, String label) {
        boolean down = kb.isKeyDown();
        int color = down ? 0x99FFFFFF : 0x66000000;
        drawRect(x, y, x + size - 1, y + size - 1, color);
        fr.drawStringWithShadow(label, x + size / 2 - 3, y + size / 2 - 4, 0xFFFFFF);
    }

    private void drawHitFlash(ScaledResolution sr) {
        long since = System.currentTimeMillis() - lastHitTime;
        if (since > 300) return;

        float alpha = 1.0F - (since / 300F);
        int cx = sr.getScaledWidth() / 2;
        int cy = sr.getScaledHeight() / 2;
        int color = ((int) (alpha * 255) << 24) | 0xFF0000;
        drawRect(cx - 6, cy - 6, cx + 6, cy + 6, color);
    }

    private void drawRect(int left, int top, int right, int bottom, int color) {
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        float a = (color >> 24 & 255) / 255.0F;
        float r = (color >> 16 & 255) / 255.0F;
        float g = (color >> 8 & 255) / 255.0F;
        float b = (color & 255) / 255.0F;
        GL11.glColor4f(r, g, b, a);
        GL11.glBegin(GL11.GL_QUADS);
        GL11.glVertex2d(left, bottom);
        GL11.glVertex2d(right, bottom);
        GL11.glVertex2d(right, top);
        GL11.glVertex2d(left, top);
        GL11.glEnd();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
    }
}
