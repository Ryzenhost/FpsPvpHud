package com.fpspvp.hud;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = FpsPvpHud.MODID, name = FpsPvpHud.NAME, version = FpsPvpHud.VERSION, clientSideOnly = true)
public class FpsPvpHud {

    public static final String MODID = "fpspvphud";
    public static final String NAME = "FPS PvP HUD";
    public static final String VERSION = "1.0";

    public static ModConfig config;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        config = new ModConfig(event.getSuggestedConfigurationFile());
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new KeybindHandler());
        MinecraftForge.EVENT_BUS.register(new HudOverlay());
    }
}
