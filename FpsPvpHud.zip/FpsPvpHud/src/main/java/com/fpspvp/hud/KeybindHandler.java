package com.fpspvp.hud;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

/**
 * Nhan Shift + Chuot phai (khi khong dang cam item co the su dung duoc / khong dang trong GUI khac)
 * de mo menu ClickGui.
 */
public class KeybindHandler {

    private boolean wasPressed = false;

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        boolean shiftDown = Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT);
        boolean rightDown = Mouse.isButtonDown(1);

        if (shiftDown && rightDown) {
            if (!wasPressed && mc.currentScreen == null) {
                mc.displayGuiScreen(new ClickGui());
            }
            wasPressed = true;
        } else {
            wasPressed = false;
        }
    }
}
