package com.fpspvp.hud;

import net.minecraftforge.common.config.Configuration;

import java.io.File;

public class ModConfig {

    public boolean showFps = true;
    public boolean showCps = true;
    public boolean showKeystrokes = true;
    public boolean showHitColor = true;

    private final Configuration config;

    public ModConfig(File file) {
        config = new Configuration(file);
        load();
    }

    public void load() {
        config.load();
        showFps = config.getBoolean("showFps", "modules", true, "Hien thi FPS");
        showCps = config.getBoolean("showCps", "modules", true, "Hien thi CPS (clicks per second)");
        showKeystrokes = config.getBoolean("showKeystrokes", "modules", true, "Hien thi Keystrokes WASD");
        showHitColor = config.getBoolean("showHitColor", "modules", true, "Doi mau crosshair khi trung don");
        if (config.hasChanged()) config.save();
    }

    public void save() {
        config.get("modules", "showFps", showFps).set(showFps);
        config.get("modules", "showCps", showCps).set(showCps);
        config.get("modules", "showKeystrokes", showKeystrokes).set(showKeystrokes);
        config.get("modules", "showHitColor", showHitColor).set(showHitColor);
        config.save();
    }
}
