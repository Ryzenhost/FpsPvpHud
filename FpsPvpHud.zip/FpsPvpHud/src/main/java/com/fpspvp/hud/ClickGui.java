package com.fpspvp.hud;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;

public class ClickGui extends GuiScreen {

    @Override
    public void initGui() {
        buttonList.clear();
        int cx = width / 2 - 60;
        int y = height / 2 - 60;

        buttonList.add(new GuiButton(0, cx, y, 120, 20, label("FPS", FpsPvpHud.config.showFps)));
        buttonList.add(new GuiButton(1, cx, y + 24, 120, 20, label("CPS", FpsPvpHud.config.showCps)));
        buttonList.add(new GuiButton(2, cx, y + 48, 120, 20, label("Keystrokes", FpsPvpHud.config.showKeystrokes)));
        buttonList.add(new GuiButton(3, cx, y + 72, 120, 20, label("Hit Color", FpsPvpHud.config.showHitColor)));
    }

    private String label(String name, boolean on) {
        return name + ": " + (on ? "BAT" : "TAT");
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        switch (button.id) {
            case 0: FpsPvpHud.config.showFps = !FpsPvpHud.config.showFps; break;
            case 1: FpsPvpHud.config.showCps = !FpsPvpHud.config.showCps; break;
            case 2: FpsPvpHud.config.showKeystrokes = !FpsPvpHud.config.showKeystrokes; break;
            case 3: FpsPvpHud.config.showHitColor = !FpsPvpHud.config.showHitColor; break;
            default: return;
        }
        FpsPvpHud.config.save();
        initGui();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        drawCenteredString(fontRendererObj, "FPS PvP HUD - Menu", width / 2, height / 2 - 90, 0xFFFFFF);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
