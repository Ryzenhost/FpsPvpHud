# FPS PvP HUD — Mod Forge 1.8.9

Đây chỉ là **HUD hiển thị thông tin** (FPS, CPS, Keystrokes, đổi màu khi trúng đòn),
KHÔNG có aimbot/killaura/reach. Mở menu bằng giữ **Shift + chuột phải**.

## Vì sao mình không đưa sẵn file.jar?

Build ra .jar cần ForgeGradle tải Forge MDK 1.8.9 + Minecraft libs từ mạng.
Việc build phải chạy trên máy/thiết bị của bạn (có internet lúc build).

## Cách build trên PC (khuyên dùng — nhanh và ổn định hơn Termux nhiều)

Yêu cầu: JDK 8, có mạng.

```
cd FpsPvpHud
./gradlew build        # Linux/Mac
gradlew.bat build       # Windows
```

File jar ra ở: `build/libs/FpsPvpHud-1.0.jar`
Copy file đó vào thư mục `mods` của Minecraft Forge 1.8.9.

## Cách build bằng Termux (Android)

Lưu ý: ForgeGradle 1.8.9 khá nặng, cần JDK 8 và tải khá nhiều dữ liệu (~1GB+),
Termux có thể chạy được nhưng chậm và dễ lỗi do thiếu RAM/dung lượng. Máy yếu nên build trên PC.

```bash
# 1. Cài gói cần thiết
pkg update && pkg upgrade -y
pkg install -y openjdk-8 wget unzip git

# 2. Giải nén project (giả sử bạn đã có FpsPvpHud.zip trong ~/storage/downloads)
termux-setup-storage
cd ~
unzip ~/storage/downloads/FpsPvpHud.zip -d ~/FpsPvpHud_project
cd ~/FpsPvpHud_project/FpsPvpHud

# 3. Cấp quyền chạy cho gradlew
chmod +x gradlew

# 4. Build (lần đầu sẽ tải Forge + MCP, cần mạng ổn định, có thể mất 10-30 phút)
./gradlew build --stacktrace

# 5. Lấy file jar vừa build ra
ls build/libs/
# -> FpsPvpHud-1.0.jar

# 6. Copy vào thư mục mods của Minecraft (ví dụ nếu dùng launcher trên Android)
cp build/libs/FpsPvpHud-1.0.jar /sdcard/games/.minecraft/mods/
```

Nếu Termux báo thiếu JDK 8 (bản Termux mới chỉ có JDK 17/21), bạn có thể cần
cài JDK 8 thủ công (tải bản AdoptOpenJDK/Temurin 8 cho Android arm64) vì
ForgeGradle cho 1.8.9 yêu cầu đúng Java 8.

## Cách build bằng GitHub Actions (khuyên dùng nếu máy yếu / Termux RAM thấp)

Không tốn RAM/pin điện thoại, GitHub build hộ, bạn chỉ cần tải file jar về.

1. Tạo tài khoản GitHub (nếu chưa có) tại https://github.com
2. Tạo repo mới (Private hay Public đều được), ví dụ tên `FpsPvpHud`.
3. Upload toàn bộ nội dung thư mục `FpsPvpHud` (bao gồm cả thư mục `.github`) lên repo đó.
   - Cách dễ nhất trên điện thoại: vào repo trên GitHub → "Add file" → "Upload files" →
     kéo thả từng file/thư mục vào (nhớ đảm bảo đường dẫn `.github/workflows/build.yml`
     giữ đúng cấu trúc thư mục).
   - Hoặc dùng Termux với `git`:
     ```bash
     cd FpsPvpHud
     git init
     git add .
     git commit -m "init"
     git branch -M main
     git remote add origin https://github.com/<ten-user>/FpsPvpHud.git
     git push -u origin main
     ```
4. Vào tab **Actions** trên trang repo GitHub → sẽ thấy workflow "Build FpsPvpHud"
   tự chạy (hoặc bấm "Run workflow" nếu chưa tự chạy).
5. Đợi vài phút cho build xong (dấu tick xanh ✅).
6. Bấm vào lượt chạy đó → kéo xuống mục **Artifacts** → tải file `FpsPvpHud-jar.zip` về.
7. Giải nén ra, bên trong là `FpsPvpHud-1.0.jar` — copy file này vào thư mục `mods`.

## Sau khi có file jar

1. Cài Minecraft Forge cho bản 1.8.9 (client Forge, không phải vanilla).
2. Copy file `.jar` vừa build vào thư mục `mods` (thường ở `.minecraft/mods`).
3. Mở game, vào thế giới/server, giữ **Shift + chuột phải** để mở menu bật/tắt
   FPS, CPS, Keystrokes, Hit Color.
