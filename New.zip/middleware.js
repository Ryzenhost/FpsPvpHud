import { NextResponse } from "next/server";

// Chỉ kiểm tra có cookie hay không (nhẹ, chạy ở edge).
// Xác thực đầy đủ được thực hiện trong từng trang / API route.
export function middleware(request) {
  const { pathname, search } = request.nextUrl;
  const hasSession = request.cookies.has("session");

  if ((pathname.startsWith("/chat") || pathname.startsWith("/admin")) && !hasSession) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.search = `?next=${encodeURIComponent(pathname + search)}`;
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/chat/:path*", "/admin/:path*"],
};
