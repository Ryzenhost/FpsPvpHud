"use client";

import { useEffect, useState } from "react";

async function api(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Có lỗi xảy ra");
  return data;
}

export default function AdminPanel({ me }) {
  const [tab, setTab] = useState("models");

  return (
    <div className="admin-wrap">
      <header className="admin-header">
        <div className="brand">
          <span className="logo">✦</span> Quản trị
        </div>
        <div className="row gap">
          <span className="muted small">{me.email}</span>
          <a className="btn btn-ghost" href="/chat">
            ← Về chat
          </a>
        </div>
      </header>

      <div className="tabs">
        <button className={`tab ${tab === "models" ? "active" : ""}`} onClick={() => setTab("models")}>
          Model AI
        </button>
        <button className={`tab ${tab === "users" ? "active" : ""}`} onClick={() => setTab("users")}>
          Tài khoản
        </button>
      </div>

      {tab === "models" ? <ModelsTab /> : <UsersTab me={me} />}
    </div>
  );
}

function StatusLine({ status }) {
  if (!status.text) return null;
  return status.type === "ok" ? <p className="ok-text">{status.text}</p> : <p className="error-banner">{status.text}</p>;
}

/* ================= MODELS ================= */

const EMPTY_MODEL = {
  name: "",
  modelId: "",
  baseUrl: "https://api.openai.com/v1",
  apiKeyEnv: "OPENAI_API_KEY",
  apiKey: "",
  enabled: true,
};

function ModelsTab() {
  const [models, setModels] = useState([]);
  const [form, setForm] = useState(EMPTY_MODEL);
  const [status, setStatus] = useState({ type: "", text: "" });
  const [saving, setSaving] = useState(false);

  async function load() {
    const data = await api("/api/admin/models");
    setModels(data.models);
  }

  useEffect(() => {
    load().catch((e) => setStatus({ type: "err", text: e.message }));
  }, []);

  async function run(fn, successText) {
    setStatus({ type: "", text: "" });
    try {
      await fn();
      if (successText) setStatus({ type: "ok", text: successText });
      await load();
    } catch (e) {
      setStatus({ type: "err", text: e.message });
    }
  }

  async function addModel(e) {
    e.preventDefault();
    setSaving(true);
    await run(async () => {
      await api("/api/admin/models", { method: "POST", body: JSON.stringify(form) });
      setForm((f) => ({ ...EMPTY_MODEL, baseUrl: f.baseUrl, apiKeyEnv: f.apiKeyEnv }));
    }, "Đã thêm model");
    setSaving(false);
  }

  const toggle = (m) =>
    run(() => api("/api/admin/models", { method: "PATCH", body: JSON.stringify({ id: m.id, enabled: !m.enabled }) }));

  const remove = (m) => {
    if (window.confirm(`Xóa model "${m.name}"?`)) {
      run(() => api(`/api/admin/models?id=${m.id}`, { method: "DELETE" }), "Đã xóa model");
    }
  };

  const setField = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  return (
    <div className="grid-2">
      <div className="card">
        <h3>Thêm model mới</h3>
        <form className="stack" onSubmit={addModel}>
          <label>
            Tên hiển thị
            <input required value={form.name} onChange={setField("name")} placeholder="GPT-4o mini" />
          </label>
          <label>
            Model ID (theo nhà cung cấp)
            <input required value={form.modelId} onChange={setField("modelId")} placeholder="gpt-4o-mini" />
          </label>
          <label>
            Base URL (tương thích OpenAI)
            <input required value={form.baseUrl} onChange={setField("baseUrl")} />
          </label>
          <label>
            Tên biến môi trường chứa API key
            <input value={form.apiKeyEnv} onChange={setField("apiKeyEnv")} placeholder="OPENAI_API_KEY" />
          </label>
          <label>
            API key (tuỳ chọn, lưu phía server)
            <input type="password" value={form.apiKey} onChange={setField("apiKey")} placeholder="Để trống nếu dùng biến môi trường" />
          </label>
          <label className="check">
            <input type="checkbox" checked={form.enabled} onChange={(e) => setForm((f) => ({ ...f, enabled: e.target.checked }))} />
            Bật ngay cho người dùng
          </label>
          <button className="btn btn-primary" disabled={saving}>
            {saving ? "Đang lưu..." : "Thêm model"}
          </button>
          <StatusLine status={status} />
        </form>
      </div>

      <div className="card">
        <h3>Danh sách model ({models.length})</h3>
        <div className="list">
          {models.length === 0 && <p className="muted">Chưa có model nào. Thêm model ở form bên trái.</p>}
          {models.map((m) => (
            <div className="item" key={m.id}>
              <div className="meta">
                <b>
                  {m.name}{" "}
                  {!m.enabled && <span className="badge off">Đang tắt</span>}
                </b>
                <span>
                  {m.modelId} · {m.baseUrl}
                </span>
                <span>
                  {m.hasKey ? <span className="badge ok">Có API key</span> : <span className="badge warn">Thiếu API key</span>}
                </span>
              </div>
              <div className="actions">
                <button className="btn btn-sm" onClick={() => toggle(m)}>
                  {m.enabled ? "Tắt" : "Bật"}
                </button>
                <button className="btn btn-sm btn-danger" onClick={() => remove(m)}>
                  Xóa
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ================= USERS ================= */

function UsersTab({ me }) {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "user" });
  const [status, setStatus] = useState({ type: "", text: "" });
  const [saving, setSaving] = useState(false);

  async function load() {
    const data = await api("/api/admin/users");
    setUsers(data.users);
  }

  useEffect(() => {
    load().catch((e) => setStatus({ type: "err", text: e.message }));
  }, []);

  async function run(fn, successText) {
    setStatus({ type: "", text: "" });
    try {
      await fn();
      if (successText) setStatus({ type: "ok", text: successText });
      await load();
    } catch (e) {
      setStatus({ type: "err", text: e.message });
    }
  }

  async function createUser(e) {
    e.preventDefault();
    setSaving(true);
    await run(async () => {
      await api("/api/admin/users", { method: "POST", body: JSON.stringify(form) });
      setForm({ name: "", email: "", password: "", role: "user" });
    }, "Đã tạo tài khoản");
    setSaving(false);
  }

  const patch = (u, body, text = "Đã cập nhật") =>
    run(() => api("/api/admin/users", { method: "PATCH", body: JSON.stringify({ id: u.id, ...body }) }), text);

  const resetPassword = (u) => {
    const pw = window.prompt(`Mật khẩu mới cho ${u.email} (tối thiểu 6 ký tự):`);
    if (pw) patch(u, { password: pw }, "Đã đặt lại mật khẩu");
  };

  const remove = (u) => {
    if (window.confirm(`Xóa tài khoản ${u.email} và toàn bộ lịch sử chat?`)) {
      run(() => api(`/api/admin/users?id=${u.id}`, { method: "DELETE" }), "Đã xóa tài khoản");
    }
  };

  const setField = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  return (
    <div className="grid-2">
      <div className="card">
        <h3>Tạo tài khoản</h3>
        <form className="stack" onSubmit={createUser}>
          <label>
            Họ tên
            <input value={form.name} onChange={setField("name")} placeholder="Tên hiển thị" />
          </label>
          <label>
            Email
            <input type="email" required value={form.email} onChange={setField("email")} />
          </label>
          <label>
            Mật khẩu (tối thiểu 6 ký tự)
            <input type="password" required minLength={6} value={form.password} onChange={setField("password")} />
          </label>
          <label>
            Vai trò
            <select value={form.role} onChange={setField("role")}>
              <option value="user">Người dùng</option>
              <option value="admin">Admin</option>
            </select>
          </label>
          <button className="btn btn-primary" disabled={saving}>
            {saving ? "Đang tạo..." : "Tạo tài khoản"}
          </button>
          <StatusLine status={status} />
        </form>
      </div>

      <div className="card">
        <h3>Danh sách tài khoản ({users.length})</h3>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Tài khoản</th>
                <th>Vai trò</th>
                <th>Trạng thái</th>
                <th>Hội thoại</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => {
                const self = u.id === me.id;
                return (
                  <tr key={u.id}>
                    <td>
                      <b>{u.name}</b>
                      <div className="muted small">
                        {u.email}
                        {self && " (bạn)"}
                      </div>
                    </td>
                    <td>
                      <span className={`badge ${u.role === "admin" ? "ok" : ""}`}>{u.role}</span>
                    </td>
                    <td>
                      {u.active ? <span className="badge ok">Hoạt động</span> : <span className="badge warn">Đã khóa</span>}
                    </td>
                    <td className="muted">{u.conversationCount}</td>
                    <td>
                      <div className="actions">
                        <button
                          className="btn btn-sm"
                          disabled={self}
                          onClick={() => patch(u, { role: u.role === "admin" ? "user" : "admin" }, "Đã đổi vai trò")}
                        >
                          {u.role === "admin" ? "Hạ quyền" : "Lên admin"}
                        </button>
                        <button
                          className="btn btn-sm"
                          disabled={self}
                          onClick={() => patch(u, { active: !u.active }, u.active ? "Đã khóa tài khoản" : "Đã mở khóa")}
                        >
                          {u.active ? "Khóa" : "Mở khóa"}
                        </button>
                        <button className="btn btn-sm" onClick={() => resetPassword(u)}>
                          Đặt lại MK
                        </button>
                        <button className="btn btn-sm btn-danger" disabled={self} onClick={() => remove(u)}>
                          Xóa
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
