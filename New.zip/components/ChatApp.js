"use client";

import { useEffect, useRef, useState } from "react";

async function api(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Có lỗi xảy ra");
  return data;
}

export default function ChatApp({ user }) {
  const [models, setModels] = useState([]);
  const [model, setModel] = useState("");
  const [conversations, setConversations] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const bottomRef = useRef(null);

  async function loadConversations() {
    const data = await api("/api/conversations");
    setConversations(data.conversations);
  }

  useEffect(() => {
    api("/api/models")
      .then((data) => {
        setModels(data.models);
        if (data.models[0]) setModel(data.models[0].id);
      })
      .catch((e) => setError(e.message));
    loadConversations().catch((e) => setError(e.message));
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, sending]);

  async function openConversation(id) {
    setError("");
    setActiveId(id);
    setSidebarOpen(false);
    try {
      const data = await api(`/api/conversations/${id}`);
      setMessages(data.conversation.messages);
      if (models.some((m) => m.id === data.conversation.model)) {
        setModel(data.conversation.model);
      }
    } catch (e) {
      setError(e.message);
    }
  }

  function newChat() {
    setActiveId(null);
    setMessages([]);
    setError("");
    setSidebarOpen(false);
  }

  async function removeConversation(e, id) {
    e.stopPropagation();
    if (!window.confirm("Xóa cuộc trò chuyện này?")) return;
    try {
      await api(`/api/conversations/${id}`, { method: "DELETE" });
      if (id === activeId) newChat();
      await loadConversations();
    } catch (err) {
      setError(err.message);
    }
  }

  async function sendMessage(e) {
    e?.preventDefault();
    const text = input.trim();
    if (!text || sending || !model) return;

    const tempId = `tmp-${Date.now()}`;
    setInput("");
    setError("");
    setSending(true);
    setMessages((prev) => [...prev, { id: tempId, role: "user", content: text }]);

    try {
      const data = await api("/api/chat", {
        method: "POST",
        body: JSON.stringify({ conversationId: activeId, modelId: model, message: text }),
      });
      await openConversation(data.conversation.id);
      await loadConversations();
    } catch (err) {
      setError(err.message);
      setMessages((prev) => prev.filter((m) => m.id !== tempId));
      setInput(text);
    } finally {
      setSending(false);
    }
  }

  function onKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    window.location.href = "/login";
  }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${sidebarOpen ? "open" : ""}`}>
        <div className="sidebar-top">
          <div className="brand">
            <span className="logo">✦</span> AI Chat
          </div>
          <button className="btn btn-primary btn-block" onClick={newChat}>
            + Cuộc trò chuyện mới
          </button>
        </div>

        <div className="conv-list">
          {conversations.length === 0 && <p className="muted small">Chưa có cuộc trò chuyện nào.</p>}
          {conversations.map((c) => (
            <div
              key={c.id}
              className={`conv-item ${c.id === activeId ? "active" : ""}`}
              onClick={() => openConversation(c.id)}
            >
              <span className="conv-title">{c.title}</span>
              <button className="icon-btn" title="Xóa" onClick={(e) => removeConversation(e, c.id)}>
                ✕
              </button>
            </div>
          ))}
        </div>

        <div className="sidebar-bottom">
          <div className="user-chip">
            <div className="avatar">{(user.name || "U")[0].toUpperCase()}</div>
            <div className="user-meta">
              <b>{user.name}</b>
              <span className="muted small">{user.email}</span>
            </div>
          </div>
          {user.role === "admin" && (
            <a className="btn btn-ghost btn-block" href="/admin">
              ⚙ Quản trị
            </a>
          )}
          <button className="btn btn-ghost btn-block" onClick={logout}>
            Đăng xuất
          </button>
        </div>
      </aside>

      <main className="chat-main">
        <header className="chat-header">
          <button className="btn btn-ghost menu-btn" onClick={() => setSidebarOpen((o) => !o)}>
            ☰
          </button>
          <select
            className="model-select"
            value={model}
            onChange={(e) => setModel(e.target.value)}
            disabled={models.length === 0}
          >
            {models.length === 0 && <option value="">Chưa có model</option>}
            {models.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name}
              </option>
            ))}
          </select>
        </header>

        <div className="messages">
          {messages.length === 0 && (
            <div className="empty">
              <div className="empty-icon">✦</div>
              <h2>Xin chào, {user.name}!</h2>
              <p className="muted">
                {models.length === 0
                  ? "Admin chưa thêm model nào. Hãy quay lại sau."
                  : "Hãy đặt câu hỏi để bắt đầu trò chuyện."}
              </p>
            </div>
          )}

          {messages.map((m) => (
            <div key={m.id} className={`msg-row ${m.role}`}>
              <div className="bubble">{m.content}</div>
            </div>
          ))}

          {sending && (
            <div className="msg-row assistant">
              <div className="bubble typing">
                <span />
                <span />
                <span />
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {error && <div className="error-banner">{error}</div>}

        <form className="composer" onSubmit={sendMessage}>
          <textarea
            rows={1}
            placeholder={models.length ? "Nhập tin nhắn... (Enter để gửi, Shift+Enter xuống dòng)" : "Chưa có model để chat"}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={onKeyDown}
            disabled={!model}
          />
          <button className="btn btn-primary send-btn" disabled={sending || !input.trim() || !model}>
            Gửi
          </button>
        </form>
      </main>
    </div>
  );
}
