import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { publicUser } from "@/lib/serialize";
import AdminPanel from "@/components/AdminPanel";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role !== "admin") redirect("/chat");
  return <AdminPanel me={publicUser(user)} />;
}
