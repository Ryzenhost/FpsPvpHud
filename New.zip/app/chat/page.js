import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { publicUser } from "@/lib/serialize";
import ChatApp from "@/components/ChatApp";

export const dynamic = "force-dynamic";

export default async function ChatPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return <ChatApp user={publicUser(user)} />;
}
