import "./globals.css";

export const metadata = {
  title: "AI Chat",
  description: "Chatbot AI đa mô hình",
};

export default function RootLayout({ children }) {
  return (
    <html lang="vi">
      <body>{children}</body>
    </html>
  );
}
