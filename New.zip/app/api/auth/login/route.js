import { query } from "@/lib/db";
import { verifyPassword } from "@/lib/security";
import { sessionCookie } from "@/lib/auth";
import { ok, fail, readBody } from "@/lib/http";
import { publicUser } from "@/lib/serialize";

export const dynamic = "force-dynamic";

export async function POST(req) {
  const body = await readBody(req);
  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");

  const user = await query((db) => db.users.find((u) => u.email === email));
  if (!user || !verifyPassword(password, user.passwordHash)) {
    return fail("Email hoặc mật khẩu không đúng", 401);
  }
  if (!user.active) return fail("Tài khoản đã bị khóa", 403);

  const res = ok({ user: publicUser(user) });
  res.cookies.set(sessionCookie(user.id));
  return res;
}
