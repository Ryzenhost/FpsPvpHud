import { transact } from "@/lib/db";
import { hashPassword, uid } from "@/lib/security";
import { sessionCookie } from "@/lib/auth";
import { ok, fail, readBody } from "@/lib/http";
import { publicUser } from "@/lib/serialize";

export const dynamic = "force-dynamic";

export async function POST(req) {
  const body = await readBody(req);
  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");
  const name = String(body.name || "").trim() || email.split("@")[0];

  if (!/^\S+@\S+\.\S+$/.test(email)) return fail("Email không hợp lệ");
  if (password.length < 6) return fail("Mật khẩu tối thiểu 6 ký tự");
  if (name.length > 60) return fail("Họ tên quá dài");

  const result = await transact((db) => {
    if (db.users.some((u) => u.email === email)) return { error: "Email đã được đăng ký" };
    const user = {
      id: uid(),
      email,
      name,
      passwordHash: hashPassword(password),
      role: "user",
      active: true,
      createdAt: new Date().toISOString(),
    };
    db.users.push(user);
    return { user };
  });

  if (result.error) return fail(result.error, 409);

  const res = ok({ user: publicUser(result.user) }, 201);
  res.cookies.set(sessionCookie(result.user.id));
  return res;
}
