import { getCurrentUser } from "@/lib/auth";
import { ok, fail } from "@/lib/http";
import { publicUser } from "@/lib/serialize";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return fail("Chưa đăng nhập", 401);
  return ok({ user: publicUser(user) });
}
