import { query, transact } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { uid } from "@/lib/security";
import { ok, fail, readBody } from "@/lib/http";
import { summary } from "@/lib/serialize";

export const dynamic = "force-dynamic";
export const maxDuration = 60; // giây (giới hạn của Vercel)

const HISTORY_LIMIT = 20;
const MAX_CHARS = 8000;

export async function POST(req) {
  const user = await getCurrentUser();
  if (!user) return fail("Chưa đăng nhập", 401);

  const body = await readBody(req);
  const conversationId = body.conversationId || null;
  const modelId = String(body.modelId || "");
  const text = String(body.message || "").trim();

  if (!text) return fail("Tin nhắn trống");
  if (text.length > MAX_CHARS) return fail(`Tin nhắn quá dài (tối đa ${MAX_CHARS} ký tự)`);

  // 1. Lấy model + lịch sử hội thoại
  const picked = await query((db) => {
    const model = db.models.find((m) => m.id === modelId && m.enabled);
    if (!model) return { error: "Model không tồn tại hoặc đã bị tắt", status: 400 };

    let history = [];
    if (conversationId) {
      const conv = db.conversations.find((c) => c.id === conversationId && c.userId === user.id);
      if (!conv) return { error: "Không tìm thấy cuộc trò chuyện", status: 404 };
      history = conv.messages.slice(-HISTORY_LIMIT).map((m) => ({ role: m.role, content: m.content }));
    }
    return { model, history };
  });
  if (picked.error) return fail(picked.error, picked.status);
  const { model, history } = picked;

  // 2. Gọi model (API tương thích OpenAI)
  const apiKey = model.apiKey || (model.apiKeyEnv && process.env[model.apiKeyEnv]);
  if (!apiKey) return fail("Model này chưa có API key. Admin hãy kiểm tra lại cấu hình.", 500);

  let reply;
  try {
    const res = await fetch(`${model.baseUrl.replace(/\/+$/, "")}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: model.modelId,
        messages: [...history, { role: "user", content: text }],
      }),
      signal: AbortSignal.timeout(55000),
      cache: "no-store",
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      return fail(data?.error?.message || `Nhà cung cấp trả lỗi (${res.status})`, 502);
    }
    reply = data?.choices?.[0]?.message?.content?.trim();
    if (!reply) return fail("Model không trả về nội dung", 502);
  } catch (e) {
    return fail(`Không gọi được model: ${e.message}`, 502);
  }

  // 3. Lưu hội thoại
  const now = new Date().toISOString();
  const { conv, assistant } = await transact((db) => {
    let conv = conversationId
      ? db.conversations.find((c) => c.id === conversationId && c.userId === user.id)
      : null;

    if (!conv) {
      conv = {
        id: uid(),
        userId: user.id,
        title: text.slice(0, 50),
        model: model.id,
        messages: [],
        createdAt: now,
        updatedAt: now,
      };
      db.conversations.push(conv);
    }

    conv.model = model.id;
    conv.updatedAt = now;
    conv.messages.push({ id: uid(), role: "user", content: text, createdAt: now });
    const assistant = { id: uid(), role: "assistant", content: reply, createdAt: now };
    conv.messages.push(assistant);
    return { conv, assistant };
  });

  return ok({ conversation: summary(conv), message: assistant });
}
