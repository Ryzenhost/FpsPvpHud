import { query, transact } from "@/lib/db";
import { requireAdmin } from "@/lib/auth";
import { hashPassword, uid } from "@/lib/security";
import { ok, fail, readBody } from "@/lib/http";
import { publicUser } from "@/lib/serialize";

export const dynamic = "force-dynamic";

export async function GET() {
  const { error } = await requireAdmin();
  if (error) return error;

  const users = await query((db) =>
    db.users
      .map((u) => ({
        ...publicUser(u),
        conversationCount: db.conversations.filter((c) => c.userId === u.id).length,
      }))
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
  );
  return ok({ users });
}

export async function POST(req) {
  const { error } = await requireAdmin();
  if (error) return error;

  const b = await readBody(req);
  const email = String(b.email || "").trim().toLowerCase();
  const password = String(b.password || "");
  const name = String(b.name || "").trim() || email.split("@")[0];
  const role = b.role === "admin" ? "admin" : "user";

  if (!/^\S+@\S+\.\S+$/.test(email)) return fail("Email không hợp lệ");
  if (password.length < 6) return fail("Mật khẩu tối thiểu 6 ký tự");

  const result = await transact((db) => {
    if (db.users.some((u) => u.email === email)) return { error: "Email đã tồn tại" };
    const user = {
      id: uid(),
      email,
      name,
      passwordHash: hashPassword(password),
      role,
      active: true,
      createdAt: new Date().toISOString(),
    };
    db.users.push(user);
    return { user };
  });

  if (result.error) return fail(result.error, 409);
  return ok({ user: publicUser(result.user) }, 201);
}

export async function PATCH(req) {
  const { error, user: admin } = await requireAdmin();
  if (error) return error;

  const b = await readBody(req);
  if (b.id === admin.id && ((b.role && b.role !== "admin") || b.active === false)) {
    return fail("Không thể tự hạ quyền hoặc khóa chính mình");
  }
  if (typeof b.password === "string" && b.password && b.password.length < 6) {
    return fail("Mật khẩu tối thiểu 6 ký tự");
  }

  const updated = await transact((db) => {
    const u = db.users.find((x) => x.id === b.id);
    if (!u) return null;
    if (b.role === "admin" || b.role === "user") u.role = b.role;
    if (typeof b.active === "boolean") u.active = b.active;
    if (typeof b.name === "string" && b.name.trim()) u.name = b.name.trim();
    if (typeof b.password === "string" && b.password) u.passwordHash = hashPassword(b.password);
    return u;
  });

  if (!updated) return fail("Không tìm thấy tài khoản", 404);
  return ok({ user: publicUser(updated) });
}

export async function DELETE(req) {
  const { error, user: admin } = await requireAdmin();
  if (error) return error;

  const id = new URL(req.url).searchParams.get("id");
  if (id === admin.id) return fail("Không thể tự xóa chính mình");

  const removed = await transact((db) => {
    const exists = db.users.some((u) => u.id === id);
    if (!exists) return false;
    db.users = db.users.filter((u) => u.id !== id);
    db.conversations = db.conversations.filter((c) => c.userId !== id);
    return true;
  });

  if (!removed) return fail("Không tìm thấy tài khoản", 404);
  return ok({ ok: true });
}
