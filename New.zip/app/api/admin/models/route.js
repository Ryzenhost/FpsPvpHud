import { query, transact } from "@/lib/db";
import { requireAdmin } from "@/lib/auth";
import { uid } from "@/lib/security";
import { ok, fail, readBody } from "@/lib/http";
import { publicModel } from "@/lib/serialize";

export const dynamic = "force-dynamic";

export async function GET() {
  const { error } = await requireAdmin();
  if (error) return error;

  const models = await query((db) => db.models.map(publicModel));
  return ok({ models });
}

export async function POST(req) {
  const { error } = await requireAdmin();
  if (error) return error;

  const b = await readBody(req);
  const name = String(b.name || "").trim();
  const modelId = String(b.modelId || "").trim();
  const baseUrl = String(b.baseUrl || "https://api.openai.com/v1").trim();

  if (!name || !modelId) return fail("Thiếu tên hiển thị hoặc Model ID");
  if (!/^https?:\/\//.test(baseUrl)) return fail("Base URL phải bắt đầu bằng http:// hoặc https://");

  const model = {
    id: uid(),
    name,
    modelId,
    baseUrl,
    apiKeyEnv: String(b.apiKeyEnv || "").trim(),
    apiKey: String(b.apiKey || "").trim(),
    enabled: b.enabled !== false,
    createdAt: new Date().toISOString(),
  };

  await transact((db) => {
    db.models.push(model);
  });
  return ok({ model: publicModel(model) }, 201);
}

export async function PATCH(req) {
  const { error } = await requireAdmin();
  if (error) return error;

  const b = await readBody(req);
  const updated = await transact((db) => {
    const m = db.models.find((x) => x.id === b.id);
    if (!m) return null;
    for (const key of ["name", "modelId", "baseUrl", "apiKeyEnv"]) {
      if (typeof b[key] === "string") m[key] = b[key].trim();
    }
    if (typeof b.enabled === "boolean") m.enabled = b.enabled;
    if (typeof b.apiKey === "string" && b.apiKey.trim()) m.apiKey = b.apiKey.trim();
    if (b.clearKey === true) m.apiKey = "";
    return m;
  });

  if (!updated) return fail("Không tìm thấy model", 404);
  return ok({ model: publicModel(updated) });
}

export async function DELETE(req) {
  const { error } = await requireAdmin();
  if (error) return error;

  const id = new URL(req.url).searchParams.get("id");
  const removed = await transact((db) => {
    const before = db.models.length;
    db.models = db.models.filter((m) => m.id !== id);
    return before !== db.models.length;
  });
  if (!removed) return fail("Không tìm thấy model", 404);
  return ok({ ok: true });
}
