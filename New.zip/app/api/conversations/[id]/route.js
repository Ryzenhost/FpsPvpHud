import { query, transact } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { ok, fail } from "@/lib/http";
import { summary } from "@/lib/serialize";

export const dynamic = "force-dynamic";

export async function GET(_req, { params }) {
  const user = await getCurrentUser();
  if (!user) return fail("Chưa đăng nhập", 401);

  const conv = await query((db) =>
    db.conversations.find((c) => c.id === params.id && c.userId === user.id)
  );
  if (!conv) return fail("Không tìm thấy cuộc trò chuyện", 404);

  return ok({
    conversation: {
      ...summary(conv),
      messages: conv.messages.map(({ id, role, content, createdAt }) => ({ id, role, content, createdAt })),
    },
  });
}

export async function DELETE(_req, { params }) {
  const user = await getCurrentUser();
  if (!user) return fail("Chưa đăng nhập", 401);

  const removed = await transact((db) => {
    const before = db.conversations.length;
    db.conversations = db.conversations.filter((c) => !(c.id === params.id && c.userId === user.id));
    return before !== db.conversations.length;
  });
  if (!removed) return fail("Không tìm thấy cuộc trò chuyện", 404);
  return ok({ ok: true });
}
