import { query, transact } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { uid } from "@/lib/security";
import { ok, fail, readBody } from "@/lib/http";
import { summary } from "@/lib/serialize";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return fail("Chưa đăng nhập", 401);

  const conversations = await query((db) =>
    db.conversations
      .filter((c) => c.userId === user.id)
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
      .map(summary)
  );
  return ok({ conversations });
}

export async function POST(req) {
  const user = await getCurrentUser();
  if (!user) return fail("Chưa đăng nhập", 401);

  const body = await readBody(req);
  const now = new Date().toISOString();
  const conv = {
    id: uid(),
    userId: user.id,
    title: "Cuộc trò chuyện mới",
    model: String(body.model || ""),
    messages: [],
    createdAt: now,
    updatedAt: now,
  };
  await transact((db) => {
    db.conversations.push(conv);
  });
  return ok({ conversation: summary(conv) }, 201);
}
