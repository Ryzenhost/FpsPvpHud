import { query } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { ok, fail } from "@/lib/http";

export const dynamic = "force-dynamic";

// Người dùng thường chỉ thấy các model đang bật (không lộ URL hay key)
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return fail("Chưa đăng nhập", 401);

  const models = await query((db) =>
    db.models.filter((m) => m.enabled).map((m) => ({ id: m.id, name: m.name }))
  );
  return ok({ models });
}
